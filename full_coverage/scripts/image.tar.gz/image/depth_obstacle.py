#!/usr/bin/env python

import rospy
from sensor_msgs.msg import Image as msg_Image
from cv_bridge import CvBridge, CvBridgeError
import sys
import os
import cv2

bridge = CvBridge()
global image

def imageDepthCallback(data):
    global image

    try:
        cv_image = bridge.imgmsg_to_cv2(data, data.encoding)
        pix = (data.width/2, data.height/2)

        obstacle = 'flase'
        preSlope = 0
        flag = False
        point = [0,0]
        for h in range(data.height-100,200,-10):
            slope = 0
            for j in range(h,h-10,-1):
                slope += abs(int(cv_image[j,pix[0]]) - int(cv_image[j-1,pix[0]]))
            slope = slope/10
            if 0== slope and not(30<=slope):
                obstacle = True
                inSlope = slope
                if flag == False:
                    point[1] = h
                    flag = True
            elif 2<=slope and flag == True:
                point[0] = h
                outSlope = slope

            preSlope = slope
            
        # sys.stdout.write('%s: Depth at center(%d, %d): %f(mm) : %s \r' % (self.topic, slope, cv_image[data.height-1,pix[0]], cv_image[data.height-11, pix[0]],obstacle))
        # sys.stdout.flush()

        if obstacle == True :
            cv2.line(image,(data.width/2,point[0]),(data.width/2,point[1]),(255,0,0),3)


        # print('Depth at center(%d, %d): %f(mm) : %s \r' % (slope, cv_image[data.height-31,pix[0]], cv_image[data.height-41, pix[0]],obstacle))
        # print(point,inSlope,outSlope)
        cv2.imshow("image",image)
        cv2.waitKey(5)

    except CvBridgeError as e:
        print(e)
        return

def camera(msg):
    global image

    try:
    # Convert your ROS Image message to OpenCV2
        image = bridge.imgmsg_to_cv2(msg, "bgr8")
    
    except CvBridgeError, e:
        print(e)


def main():
    global image

    rospy.init_node('depth_obstacle')

    topic = '/camera/depth/image_rect_raw'
    rospy.Subscriber(topic, msg_Image,imageDepthCallback)

    img_topic = '/camera/color/image_raw'
    rospy.Subscriber(img_topic, msg_Image,camera)

    rospy.spin()

if __name__ == '__main__':
    node_name = os.path.basename(sys.argv[0]).split('.')[0]
    rospy.init_node(node_name)
    main()