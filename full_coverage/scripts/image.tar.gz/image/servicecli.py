#!/usr/bin/env python
import sys

import rospy
from full_coverage.srv import Fullpath

def add_two_ints_client(x, y):
    print ("tests0")
    rospy.wait_for_service('fullpathmove')
    print ("tests1")
    try:
        fullpath = rospy.ServiceProxy('fullpathmove', Fullpath)
        print ("tests2")
        resp1 = fullpath(x, y)
        print ("tests3")
        return resp1.result
    except rospy.ServiceException, e:
        print "Service call failed: %s"%e

def usage():
    return "%s [x y]"%sys.argv[0]

if __name__ == "__main__":
    if len(sys.argv) == 3:
        x = int(sys.argv[1])
        y = int(sys.argv[2])
    else:
        print usage()
        sys.exit(1)
    print "Requesting %s+%s"%(x, y)
    print "%s + %s = %s"%(x, y, add_two_ints_client(x, y))
