#!/usr/bin/env python

import rospy
from sensor_msgs.msg import Image as msg_Image
from std_msgs.msg import String
from cv_bridge import CvBridge, CvBridgeError
import sys
import os
import cv2

global image

bridge = CvBridge()

class ImageListener:
    def __init__(self, topic):
        self.topic = topic

        self.pub = rospy.Publisher('obstacle',String)
        self.sub = rospy.Subscriber(topic, msg_Image, self.imageDepthCallback)
        

    def imageDepthCallback(self, data):
        global image

        try:
            cv_image = bridge.imgmsg_to_cv2(data, data.encoding)
            pix = (data.width/2, data.height/2)

            obstacle = 'flase'
            inRange = []
            flag = False

            for w in range(0,data.width-1):
                if 0<cv_image[data.height/2,w]and cv_image[data.height/2,w]  <= 300:
                    inRange.append(w)
                
            #print(inRange)

            if inRange != [] :
                self.pub.publish('True')
                cv2.line(image,( inRange[0],data.height/2),( inRange[-1],data.height/2),(255,0,0),3)
            else:
                self.pub.publish('False')

        except CvBridgeError as e:
            print(e)
            return


        cv2.imshow('image',image)
        cv2.waitKey(3)

def camera(msg):
    global image
    try:
        # Convert your ROS Image message to OpenCV2
        image = bridge.imgmsg_to_cv2(msg, "bgr8")
        
    except CvBridgeError, e:
        print(e)


def main():

    topic = '/camera/depth/image_rect_raw'
    listener = ImageListener(topic)

    img_topic = '/camera/color/image_raw'

    rospy.Subscriber(img_topic,msg_Image,camera)

    
    rospy.spin()

if __name__ == '__main__':
    node_name = os.path.basename(sys.argv[0]).split('.')[0]
    rospy.init_node(node_name)
    main()