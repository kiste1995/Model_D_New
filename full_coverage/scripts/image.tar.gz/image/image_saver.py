#!/usr/bin/env python

import rospy
# ROS Image message
from sensor_msgs.msg import Image
from cv_bridge import CvBridge,CvBridgeError
# OpenCV2 for saving an image
import cv2
import threading

bridge = CvBridge()

global image
image = None


def image_save(msg):
    global image
    image = msg


def image_callback():    
    global image
    rospy.sleep(1)
    cnt = 0
    print("Received an image!")

    while True:
        try:
            # Convert your ROS Image message to OpenCV2
            cv2_img = bridge.imgmsg_to_cv2(image, "bgr8")
        except CvBridgeError, e:
            print(e)
        else:
            # Save your OpenCV2 image as a jpeg 
            print("save")
            cv2.imwrite('/home/zetabank/catkin_ws/src/full_coverage/img/camera_image'+str(cnt)+'.jpeg', cv2_img)
        cnt +=1
        rospy.sleep(2)
    # sub_once.unregister()
    # rospy.sleep(1)
    # print('1')
    # sub_once

    

def main():
    global image

    th = threading.Thread(target=image_callback)
    th.daemon = True
    print("Wait")
    rospy.sleep(2)
    print("start")
    th.start()

    rospy.init_node('image_saver')
    # Define your image topic
    image_topic = "/camera/color/image_raw"
    # Set up your subscriber and define its callback
    sub_once = rospy.Subscriber(image_topic, Image,image_save)
    # Spin until ctrl + c
    
    rospy.spin()
    



if __name__ == '__main__':
    main()
    