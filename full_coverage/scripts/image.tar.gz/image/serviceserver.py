#!/usr/bin/env python
import roslib

from full_coverage.srv import Fullpath
import rospy

def serviceproccess(req):
    print (req)
    return 33

def add_two_ints_server():
    rospy.init_node('testservice_server')
    s = rospy.Service('fullpathmove', Fullpath, serviceproccess)
    print "Ready to move."
    rospy.spin()

if __name__ == "__main__":
    add_two_ints_server()