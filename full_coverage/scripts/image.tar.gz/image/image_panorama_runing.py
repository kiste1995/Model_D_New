#!/usr/bin/env python

import rospy
# ROS Image message
from sensor_msgs.msg import Image
from cv_bridge import CvBridge,CvBridgeError
# OpenCV2 for saving an image
import cv2
import numpy as np
import threading
import os.path

bridge = CvBridge()

global cnt
cnt = 0
global img
global img_gray
global turn_point
turn_point = []
global cnt_line
cnt_line = 0
img = []
img_gray = []

location = '/home/zetabank/catkin_ws/src/full_coverage/img'

def imgLoad() :
    global cnt
    global img
    global img_gray

    while True:
        if os.path.isfile(''+location+'/camera_image'+str(cnt)+'.jpeg'):
            img.append(cv2.imread(''+location+'/camera_image'+str(cnt)+'.jpeg',cv2.IMREAD_COLOR))
            img_gray.append(cv2.cvtColor(img[cnt],cv2.COLOR_BGR2GRAY))
            cnt += 1
            print(cnt)
        else :
            # cv2.imshow('img',img[0])
            # cv2.waitKey(3)
            break


def vertical_panorama() :
    global turn_point
    global cnt_line
    next_line_flag = False
    reverse_flag = False
    horizontal_flag = True
    y_point = 0
    y_axis = 2
    sift = cv2.xfeatures2d.SIFT_create(contrastThreshold=0.005,edgeThreshold=20)

    while True:
        if cnt_line>y_point+1:

            print('vertical')
            print('y_point',y_point)

            

            kp1, des1 = sift.detectAndCompute(img_gray[turn_point[y_point]],None)
            kp2, des2 = sift.detectAndCompute(img_gray[turn_point[y_point+1]],None)


            match = cv2.BFMatcher()
            matches = match.knnMatch(des1,des2,k=2)

            good = []
            for m,n in matches:
                if m.distance < 0.3*n.distance:
                    good.append(m)

            draw_params = dict(matchColor = (0,255,0), # draw matches in green color
                   singlePointColor = None,
                   flags = 2)

            img3 = cv2.drawMatches(img[turn_point[y_point]],kp1,img[turn_point[y_point+1]],kp2,good,None,**draw_params)

            # cv2.imshow('original_image_left_keypoints1',cv2.drawKeypoints(img[0],kp1,None))
            # cv2.waitKey(20)
            # cv2.imshow('original_image_left_keypoints2',cv2.drawKeypoints(img[1],kp2,None))
            # cv2.waitKey(20)
            # cv2.imshow("original_image_drawMatches.jpg", img3)
            # cv2.waitKey(20)


            

            MIN_MATCH_COUNT = 5
            if len(good) > MIN_MATCH_COUNT:
                src_pts = np.float32([ kp1[m.queryIdx].pt for m in good ]).reshape(-1,1,2)
                dst_pts = np.float32([ kp2[m.trainIdx].pt for m in good ]).reshape(-1,1,2)

                M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC,5.0)    
                h,w = img_gray[turn_point[y_point]].shape
                pts = np.float32([ [0,0],[0,h-1],[w-1,h-1],[w-1,0] ]).reshape(-1,1,2)
                dst = cv2.perspectiveTransform(pts,M)   
                img_gray[turn_point[y_point+1]] = cv2.polylines(img_gray[turn_point[y_point+1]],[np.int32(dst)],True,255,3, cv2.LINE_AA)
                # cv2.imshow("original_image_overlapping.jpg", img_gray[turn_point[y_point+1]])
                # cv2.waitKey(10)
                # cv2.waitKey(10)
            else:
                print ("Not enough matches are found - %d/%d" % (len(good),MIN_MATCH_COUNT))

            dst = cv2.warpPerspective(img[turn_point[y_point]],M,(max(img[turn_point[y_point]].shape[1] , img[turn_point[y_point+1]].shape[1]) , img[turn_point[y_point+1]].shape[0]+img[turn_point[y_point+1]].shape[0]))  #Bottom to Top
            dst[0:img[turn_point[y_point+1]].shape[0], 0:img[turn_point[y_point+1]].shape[1]] = img[turn_point[y_point+1]]

            y_point += 1

            img[turn_point[y_point]] = dst
            
            print('turn_point=',turn_point)

        elif y_point >0:
            img[turn_point[y_point]] = trim(img[turn_point[y_point]])
            cv2.imshow('ver(dst)',img[turn_point[y_point]])
            cv2.imwrite('/home/zetabank/catkin_ws/src/full_coverage/img/result.jpeg',img[turn_point[y_point]] )
            cv2.waitKey(100)

def horizontal_panorama() :
    global cnt
    cnt_img = 0
    global cnt_line
    next_line_flag = False
    reverse_flag = False
    horizontal_flag = True
    global turn_point
    x_point = 1
    y_point = 1
    x_axis = 3  # max count of image of x_axis
    y_axis = 3
    sift = cv2.xfeatures2d.SIFT_create(contrastThreshold=0.005,edgeThreshold=20)

    

    while True:
        if cnt>cnt_img+1:
            
            # print('horizontal')
            # print('cnt_img',cnt_img)
            
            
                
            if reverse_flag:
                img[cnt_img],img[cnt_img+1] = img[cnt_img+1],img[cnt_img] # reverse
                img_gray[cnt_img],img_gray[cnt_img+1] = img_gray[cnt_img+1],img_gray[cnt_img]

            kp1, des1 = sift.detectAndCompute(img_gray[cnt_img],None)
            kp2, des2 = sift.detectAndCompute(img_gray[cnt_img+1],None)


            match = cv2.BFMatcher()
            matches = match.knnMatch(des1,des2,k=2)

            good = []
            for m,n in matches:
                if m.distance < 0.3*n.distance:
                    good.append(m)

            draw_params = dict(matchColor = (0,255,0), # draw matches in green color
                   singlePointColor = None,
                   flags = 2)

            img3 = cv2.drawMatches(img[cnt_img],kp1,img[cnt_img+1],kp2,good,None,**draw_params)

            # cv2.imshow('original_image_left_keypoints1',cv2.drawKeypoints(img[0],kp1,None))
            # cv2.waitKey(20)
            # cv2.imshow('original_image_left_keypoints2',cv2.drawKeypoints(img[1],kp2,None))
            # cv2.waitKey(20)
            # cv2.imshow("original_image_drawMatches.jpg", img3)
            # cv2.waitKey(20)


            

            MIN_MATCH_COUNT = 5
            if len(good) > MIN_MATCH_COUNT:
                src_pts = np.float32([ kp1[m.queryIdx].pt for m in good ]).reshape(-1,1,2)
                dst_pts = np.float32([ kp2[m.trainIdx].pt for m in good ]).reshape(-1,1,2)

                M, mask = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC,5.0)    
                h,w = img_gray[cnt_img].shape
                pts = np.float32([ [0,0],[0,h-1],[w-1,h-1],[w-1,0] ]).reshape(-1,1,2)
                dst = cv2.perspectiveTransform(pts,M)   
                img_gray[cnt_img+1] = cv2.polylines(img_gray[cnt_img+1],[np.int32(dst)],True,255,3, cv2.LINE_AA)
                # cv2.imshow("original_image_overlapping.jpg", img_gray[cnt_img+1])
                # cv2.waitKey(10)
                # cv2.waitKey(10)
            else:
                print ("Not enough matches are found - %d/%d" % (len(good),MIN_MATCH_COUNT))



            dst = cv2.warpPerspective(img[cnt_img],M,(img[cnt_img+1].shape[1], img[cnt_img+1].shape[0]  + img[cnt_img+1].shape[0] ))  #Right to Left
            dst[0:img[cnt_img+1].shape[0], 0:img[cnt_img+1].shape[1]] = img[cnt_img+1]

            x_point += 1
            cnt_img += 1

            img[cnt_img] = dst

            

            # if x_point == x_axis:
            #     x_point = 1
            #     reverse_flag = not reverse_flag
            #     turn_point.append(cnt_img)
            #     cv2.imwrite('/home/zetabank/catkin_ws/src/full_coverage/img/horizontal'+str(cnt_line)+'.jpeg',trim(img[turn_point[cnt_line]]))
            #     cnt_img += 1
            #     cnt_line += 1
                

        elif cnt_img >0:
                cv2.imshow('trim(dst)',trim(dst))
                cv2.imwrite('/home/zetabank/catkin_ws/src/full_coverage/img/result.jpeg',trim(dst))
                cv2.waitKey(20)

def trim(frame):
    #crop top
    if not np.sum(frame[0]):
        return trim(frame[1:])
    #crop bottom
    elif not np.sum(frame[-1]):
        return trim(frame[:-2])
    #crop left
    elif not np.sum(frame[:,0]):
        return trim(frame[:,1:]) 
    #crop right
    elif not np.sum(frame[:,-1]):
        return trim(frame[:,:-2])    
    return frame

def main () :
    global cnt
    global img
    
    rospy.init_node('image_panorama')

    # img_topic = '/camera/color/image_raw'

    # rospy.Subscriber(img_topic, Image,camera)

    

    # cv2.imshow('img_0',img[0])

    th_imgload = threading.Thread(target=imgLoad)
    th_imgload.daemon = True
    th_horizontal_panorama = threading.Thread(target=horizontal_panorama)
    th_horizontal_panorama.daemon = True
    th_imgload.start()
    th_horizontal_panorama.start()
    # th_vertical_panorama = threading.Thread(target=vertical_panorama)
    # th_vertical_panorama.daemon = True
    # th_vertical_panorama.start()

    rospy.spin()
    cv2.destroyAllWindows()


if __name__ == '__main__':
    main()