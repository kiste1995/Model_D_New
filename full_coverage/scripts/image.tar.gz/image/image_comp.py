#!/usr/bin/env python

import rospy
# ROS Image message
from sensor_msgs.msg import Image
from cv_bridge import CvBridge,CvBridgeError
# OpenCV2 for saving an image
import cv2
import numpy as np
import threading

bridge = CvBridge()

global location

location = '/home/zetabank/catkin_ws/src/full_coverage/img'

def camera (msg) :

    try:
        # Convert your ROS Image message to OpenCV2
        cv2_img = bridge.imgmsg_to_cv2(msg, "bgr8")
        gray_camera = cv2.cvtColor(cv2_img,cv2.COLOR_BGR2GRAY)
        
    except CvBridgeError, e:
        print(e)


    
    cv2.imshow('RealTime',cv2_img)

    # img = cv2.imread(''+location+'/camera_image1.jpeg',cv2.IMREAD_COLOR)
    # gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # cv2.imshow('image1',img)
    # cv2.waitKey(3)

    img = cv2.imread(''+location+'/camera_image0.jpeg',cv2.IMREAD_COLOR)
    gray_img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

    cv2.imshow('standard_img',img)

    # diff = cv2.absdiff(gray_camera,gray_img)
    diff = cv2.absdiff(cv2_img,img)
    diff = np.where(diff>35,255,diff)

    # ret,thresh = cv2.threshold(diff,127,255,0)
    # image, contours, hierarchy = cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    # line = cv2.drawContours(cv2_img, contours, -1, (0,255,0), 3)
    

    # for i in  range(diff.shape[0]):
    #     for j in range(diff.shape[1]):
    #         if diff[i,j,2] == 255:
    #             diff[i,j,2] = 0
    #             diff[i,j,0] = 0

    # diff = cv2.cvtColor(diff,cv2.COLOR_GRAY2BGR)

    B, G, R = cv2.split(diff)
    B_img, G_img, R_img = cv2.split(cv2_img)

    
    
    # R = np.where(B>250,255,R) #Red
    # G = np.where(B>250,0,G_img)
    # B = np.where(B>250,0,B_img)

    # R = np.where(G>250,255,R)
    # G = np.where(G>250,0,G)

    # R = np.where(R>200,255,R_img)
    # G = np.where(R>200,0,G)
    # B = np.where(R>200,0,B)


    B = np.where(R==255,255,B) #Blue
    G = np.where(R==255,0,G_img)
    R = np.where(R==255,0,R_img)

    B = np.where(G==255,255,B)
    G = np.where(G==255,0,G)

    B = np.where(B==255,255,B_img)
    G = np.where(B==255,0,G)
    R = np.where(B==255,0,R)

    # G = np.where(R==255,255,G) #Blue
    # R = np.where(R==255,0,R_img)
    # B = np.where(R==255,0,B_img)
    

    # G = np.where(B==255,255,G)
    # B = np.where(B==255,0,B)

    # G = np.where(G==255,255,G_img)
    # R = np.where(G==255,0,R)
    # B = np.where(G==255,0,B)
    


    

    

    diff_asemble = cv2.merge((B,G,R))

    # diff_asemble = cv2.merge((B_img,G_img,R_img))

    cv2.imshow('diff',diff)
    diff = None
    cv2.waitKey(3)

    cv2.imshow('diff_asemble',diff_asemble)


def main () :
    global pub
    
    rospy.sleep(3)
    rospy.init_node('image_comp')

    img_topic = '/camera/color/image_raw'

    rospy.Subscriber(img_topic, Image,camera)

    rospy.spin()
    cv2.destroyAllWindows()


if __name__ == '__main__':
    main()

    