#!/usr/bin/env python

import rospy
# ROS Image message
# from sensor_msgs.msg import Image
from PIL import Image
from cv_bridge import CvBridge,CvBridgeError
# OpenCV2 for saving an image
import cv2
import threading
import numpy as np

bridge = CvBridge()

def main():

    rospy.sleep(3)
    rospy.init_node('image_show')

    img = cv2.imread('/home/zetabank/test_map.jpg')

    kernel = cv2.getStructuringElement(cv2.MORPH_CROSS, (9, 9))
    dst = cv2.morphologyEx(img, cv2.MORPH_CLOSE, kernel, iterations=1)

    cv2.imshow('test',img)
    cv2.waitKey(10)

    cv2.imshow('gradient',dst)    
    cv2.waitKey(20)


    rospy.spin()
    cv2.destroyAllWindows()




if __name__ == '__main__':
    main()