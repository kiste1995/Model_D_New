#!/usr/bin/env python

import rospy
# ROS Image message
from sensor_msgs.msg import Image
from cv_bridge import CvBridge,CvBridgeError
# OpenCV2 for saving an image
import cv2
import numpy as np
import threading
import sys

bridge = CvBridge()

global location

location = '/home/zetabank/catkin_ws/src/full_coverage/img'

def camera (msg) :

    try:
        # Convert your ROS Image message to OpenCV2
        cv2_img = bridge.imgmsg_to_cv2(msg, "bgr8")
        gray_camera = cv2.cvtColor(cv2_img,cv2.COLOR_BGR2GRAY)
        
    except CvBridgeError, e:
        print(e)

    cv2.imshow('RealTime',cv2_img)
    cv2.waitKey(3)


def main () :
    global pub
    
    rospy.sleep(3)
    rospy.init_node('image_show')

    img_topic = '/camera/color/image_raw'

    rospy.Subscriber(img_topic, Image,camera)

    rospy.spin()
    cv2.destroyAllWindows()


if __name__ == '__main__':
    main()

    